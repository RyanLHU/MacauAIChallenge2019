# [Description]
# In this sample evaluation script, we evaluate the model based on a random logic

# [FREE TO UPDATE] import your modules
import sys
from PIL import Image
import numpy as np
import pickle
from sklearn.preprocessing import scale
import pandas


# [DO NOT CHANGE] Each record of "image_df" contains 5 attributes: img, x1, y1, x2, y2
def predict(image_df, testpath, submitpath):
    # [DO NOT CHANGE] loop all images for evaluation
    labels = []
    for index, row in image_df.iterrows():
        # [DO NOT CHANGE] get the image path, imagepath
        imagepath = testpath+'img/'+ row["img"]

        # [FREE TO UPDATE - begin] The prediction being made by your logic and / or model(s)
        rect = [row["x1"],row["y1"],row["x2"],row["y2"]]
        testImg = Image.open(imagepath)
        signImg = testImg.crop(rect)
        signImg = signImg.resize((100, 100), Image.BICUBIC).convert('L')
        signImg = np.asarray(signImg)     

        labels.append(signImg[0][0]%64)
        # [FREE TO UPDATE - end] The prediction being made by your logic and / or model(s)

    # [DO NOT CHANGE] return a list of labels
    return labels

