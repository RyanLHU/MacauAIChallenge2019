import sys
import numpy as np
import pandas

def predict(Imgpath,rect,user_submission_file):
	workpath=user_submission_file.rsplit('/',1)[0]+'/'	

	# for image processing
	img = []
	testImg = Image.open(Imgpath)
	testImg = testImg.resize((50, 50), Image.BICUBIC)
	testImg = np.array(testImg)
	img.append(testImg.flatten())
	img = np.array(img)

	label = img[0][0]%16
	print(label)
	
	return(label)

