import os, cv2, re, random
import numpy as np
from keras.models import load_model
from PIL import Image

def predict(Imgpath,rect,user_submission_file):
    workpath=user_submission_file.rsplit('/',1)[0]+'/'  
    #print(workpath)
    img = []
    testImg = Image.open(Imgpath)
    signImg = testImg.crop(rect)
    x = (cv2.resize(np.asarray(signImg), (150,150), interpolation=cv2.INTER_CUBIC))
    x = x.reshape(1,150,150,3)

    with open(workpath+'sign.h5', 'rb') as f:
        model = load_model(workpath+'sign.h5')
        y = model.predict(np.array(x))

        y = list(y[0])
        max_value = max(y)
        label = y.index(max_value)
        return label
	
    return -1