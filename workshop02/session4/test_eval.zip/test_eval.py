from eval import predict

# Current path 
# Copy your eval.py and model files in the same folder of the test_eval.py
user_path = '.'

# Single image
img = './img/0c94c156f2da1416008550654e8ad150.jpeg'

# corresponding rect position, check result.csv
rect = (158,87,397,302)

# check result.csv
groundtruth = 51

pred = predict(Imgpath=img, rect=rect, user_submission_file=user_path)

print ("ground truth label: {} \npredict label: {}".format(groundtruth, pred))