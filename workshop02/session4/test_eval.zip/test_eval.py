from eval import predict
import pandas

# Current path 
# Copy your eval.py and model files in the same folder of the batch_eval.py
submitpath = './'
testpath = './'

image_df = pandas.read_csv(submitpath+'result.csv', encoding='utf-8', index_col=False)#error_bad_lines=False,engine='python',skiprows=2

labels = predict(image_df[["img","x1","y1","x2","y2"]], testpath, submitpath)

count=0
correct=0
if image_df.shape[0]!=len(labels):
	print("The returned labels are not complete!")

for real_label in image_df["class"]:
	if real_label==labels[count]:
		correct+=1
	count+=1

acc = correct/image_df.shape[0] * 100

print("The accuracy is {0:.2f}%".format(acc))
