# [Description]
# In this sample evaluation script, we evaluate the model being 
# trained in Session 03 which does not use the "cropped rectangle" 
# from the labeled data.

# [FREE TO UPDATE] import your modules
import os, cv2, re, random
import numpy as np
from keras.models import load_model
from PIL import Image
import pandas

# [DO NOT CHANGE] Each record of "image_df" contains 5 attributes: img, x1, y1, x2, y2
def predict(image_df, user_submission_file):
	# [DO NOT CHANGE] load the CSV file for evaluation
	workpath=user_submission_file.rsplit('/',1)[0]+'/'
	
	# [FREE TO UPDATE] load your model
	model = load_model(workpath+'sign.h5')

	# [DO NOT CHANGE] loop all images for evaluation
	labels = []
	for index, row in image_df.iterrows():
		# [DO NOT CHANGE] get the image path, imagepath
		imagepath = user_submission_file+'img/'+ row["img"]

		# [FREE TO UPDATE - begin] The prediction being made by your logic and / or model(s)
		x = (cv2.resize(cv2.imread(imagepath), (150,150), interpolation=cv2.INTER_CUBIC))
		x = x.reshape(1,150,150,3)
		y = model.predict(np.array(x))

		y = list(y[0])
		max_value = max(y)
		labels.append(y.index(max_value))
		# [FREE TO UPDATE - end] The prediction being made by your logic and / or model(s)

	# [DO NOT CHANGE] return a list of labels
	return labels
