import sys
from PIL import Image
import numpy as np
import pickle
from sklearn.preprocessing import scale
import pandas

def predict(Imgpath,rect,user_submission_file):
    workpath=user_submission_file.rsplit('/',1)[0]+'/'  
    #print(workpath)
    img = []
    testImg = Image.open(Imgpath)
    signImg = testImg.crop(rect)
    signImg = signImg.resize((100, 100), Image.BICUBIC).convert('L')
    signImg = np.asarray(signImg)     
    img = signImg.flatten().reshape(1,-1)
    scale_img = scale(img,axis=-1)
    # img.append(testImg.flatten())
    # img = np.array(img)

    if img.shape[1] != 10000:
        return(0)

    with open(workpath+'MLmodel.pickle', 'rb') as f:
        clf = pickle.load(f)
        pre = clf.predict(scale_img)
        #print(pre[0])
        return (pre[0])

    return (-1)
