import sys
from PIL import Image
import numpy as np
import pickle
import pandas

def predict(Imgpath,rect,user_submission_file):
	workpath=user_submission_file.rsplit('/',1)[0]+'/'	
	#print(workpath)
	img = []
	testImg = Image.open(Imgpath)
	testImg = testImg.resize((50, 50), Image.BICUBIC)
	testImg = np.array(testImg)
	img.append(testImg.flatten())
	img = np.array(img)

	if img.shape[1]!=7500:
		return(0)
	
	with open(workpath+'model.pickle', 'rb') as f:
		clf2 = pickle.load(f)
		pre = clf2.predict(img)
		return(pre[0])

	return(-1)
