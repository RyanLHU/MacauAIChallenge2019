# [Description]
# In this sample evaluation script, we evaluate the model being trained in Session 02.

# [FREE TO UPDATE] import your modules
import sys
from PIL import Image
import numpy as np
import pickle
from sklearn.preprocessing import scale
import pandas


# [DO NOT CHANGE] Each record of "image_df" contains 5 attributes: img, x1, y1, x2, y2
def predict(image_df, testpath, submitpath):
    # [DO NOT CHANGE] load the CSV file for evaluation
    workpath=submitpath.rsplit('/',1)[0]+'/'
    
    # [FREE TO UPDATE] load your model
    f = open(workpath+'MLmodel.pickle', 'rb')
    clf = pickle.load(f)

    # [DO NOT CHANGE] loop all images for evaluation
    labels = []
    for index, row in image_df.iterrows():
        # [DO NOT CHANGE] get the image path, imagepath
        imagepath = testpath+'img/'+ row["img"]

        # [FREE TO UPDATE - begin] The prediction being made by your logic and / or model(s)
        rect = [row["x1"],row["y1"],row["x2"],row["y2"]]
        testImg = Image.open(imagepath)
        signImg = testImg.crop(rect)
        signImg = signImg.resize((100, 100), Image.BICUBIC).convert('L')
        signImg = np.asarray(signImg)     
        img = signImg.flatten().reshape(1,-1)
        scale_img = scale(img,axis=-1)

        if img.shape[1] != 10000:
            labels.append(0)
        else:
            pre = clf.predict(scale_img)
            labels.append(pre[0])
        # [FREE TO UPDATE - end] The prediction being made by your logic and / or model(s)

    # [DO NOT CHANGE] return a list of labels
    return labels

